import { Github, Linkedin, Mail, ExternalLink, Code2, Palette, Globe, Rocket, ArrowDown } from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <header className="relative h-screen flex items-center justify-center bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500">
        <div className="absolute inset-0">
          <Image 
            src="https://images.unsplash.com/photo-1467232004584-a241de8bcf5d?auto=format&fit=crop&q=80"
            alt="Background"
            fill
            className="object-cover opacity-10"
            priority
          />
        </div>
        <div className="absolute bottom-10 animate-bounce">
          <ArrowDown className="w-6 h-6 text-white" />
        </div>
        <div className="relative text-center text-white px-4 max-w-4xl">
          <h1 className="text-6xl md:text-8xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white to-gray-200">
            Bivek Chettri
          </h1>
          <p className="text-xl md:text-3xl mb-8 text-gray-200">Crafting Digital Experiences Through Code & Design</p>
          <div className="flex justify-center space-x-8 mb-12">
            <a href="#" className="text-white hover:text-pink-200 transition-colors transform hover:scale-110">
              <Github className="w-8 h-8" />
            </a>
            <a href="#" className="text-white hover:text-pink-200 transition-colors transform hover:scale-110">
              <Linkedin className="w-8 h-8" />
            </a>
            <a href="#" className="text-white hover:text-pink-200 transition-colors transform hover:scale-110">
              <Mail className="w-8 h-8" />
            </a>
          </div>
          <a 
            href="#contact"
            className="inline-block px-8 py-4 text-lg font-semibold text-white border-2 border-white rounded-full hover:bg-white hover:text-indigo-600 transition-all duration-300 transform hover:scale-105"
          >
            Let's Create Something Amazing
          </a>
        </div>
      </header>

      {/* Services Section */}
      <section className="py-32 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-20 bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
            Expertise & Services
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
            {[
              {
                icon: Code2,
                title: "Web Development",
                description: "Building scalable and performant web applications with modern technologies"
              },
              {
                icon: Palette,
                title: "UI/UX Design",
                description: "Creating intuitive and beautiful user interfaces that delight users"
              },
              {
                icon: Globe,
                title: "SEO Optimization",
                description: "Improving visibility and driving organic traffic through search optimization"
              },
              {
                icon: Rocket,
                title: "Performance",
                description: "Optimizing applications for speed, efficiency, and user experience"
              }
            ].map((service, index) => (
              <div key={index} className="p-8 bg-gray-50 rounded-2xl shadow-lg hover:shadow-xl transition-shadow duration-300">
                <service.icon className="w-16 h-16 mx-auto mb-6 text-indigo-600" />
                <h3 className="text-2xl font-semibold mb-4 text-center">{service.title}</h3>
                <p className="text-gray-600 text-center">{service.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section className="py-32 px-4 bg-gray-100">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-20 bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
            Featured Work
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
            {[
              {
                title: "E-Commerce Platform",
                description: "A full-featured online store with real-time inventory and payment processing",
                image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=800"
              },
              {
                title: "Healthcare Dashboard",
                description: "An intuitive analytics dashboard for healthcare professionals",
                image: "https://images.unsplash.com/photo-1504868584819-f8e8b4b6d7e3?auto=format&fit=crop&q=80&w=800"
              },
              {
                title: "Social Media App",
                description: "A modern social platform with real-time messaging and content sharing",
                image: "https://images.unsplash.com/photo-1432888498266-38ffec3eaf0a?auto=format&fit=crop&q=80&w=800"
              }
            ].map((project, index) => (
              <div key={index} className="group bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300">
                <div className="relative h-64 overflow-hidden">
                  <Image 
                    src={project.image}
                    alt={project.title}
                    fill
                    className="object-cover transform group-hover:scale-110 transition-transform duration-300"
                  />
                </div>
                <div className="p-8">
                  <h3 className="text-2xl font-semibold mb-4">{project.title}</h3>
                  <p className="text-gray-600 mb-6">{project.description}</p>
                  <Link 
                    href="#"
                    className="inline-flex items-center text-indigo-600 hover:text-indigo-700 font-semibold"
                  >
                    View Case Study <ExternalLink className="ml-2 w-5 h-5" />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-32 px-4 bg-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-10 bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
            Let's Build Something Together
          </h2>
          <p className="text-xl text-gray-600 mb-12 max-w-2xl mx-auto">
            Have a project in mind? I'm always excited to collaborate on new challenges and create exceptional digital experiences.
          </p>
          <div className="space-y-6">
            <a 
              href="mailto:contact@example.com"
              className="inline-block px-12 py-5 text-lg font-semibold text-white bg-gradient-to-r from-indigo-600 to-purple-600 rounded-full hover:from-indigo-700 hover:to-purple-700 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl"
            >
              Start a Conversation
            </a>
            <div className="flex justify-center space-x-8 mt-12">
              <a href="#" className="text-gray-600 hover:text-indigo-600 transition-colors">
                <Github className="w-8 h-8" />
              </a>
              <a href="#" className="text-gray-600 hover:text-indigo-600 transition-colors">
                <Linkedin className="w-8 h-8" />
              </a>
              <a href="#" className="text-gray-600 hover:text-indigo-600 transition-colors">
                <Mail className="w-8 h-8" />
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <p className="text-gray-400">&copy; {new Date().getFullYear()} Bivek Chettri. Crafted with passion.</p>
        </div>
      </footer>
    </div>
  );
}